const btnResult = document.getElementById('result');
const birthdayElement = document.getElementById('errorMessage');
const resultMessage = document.getElementById('resultMessage');
const spanElement = document.getElementById('daysCount');

function calculatedaysUntilBirthday() {

    // получаем элемент с  html  документа
    const dateElement = document.getElementById('date');
    // создаем переменную и получаем сегодняшную дату
    const currentDate = new Date();
    // получаем значение с input
    const selectDate = new Date(dateElement.value);zzz
    let timeDifference = 0;
    // условия
    if(!dateElement.value){
        birthdayElement.style.background ='red';
        birthdayElement.textContent = 'пожалуйста введите свою дату рождение';
        birthdayElement.style.display = 'block';
        errorMessageContainer.style.display = 'block';
        return;
    } else {
        // получаем время чтобы получить в милисекундах
        const dateDifference = selectDate.getTime() - currentDate.getTime();
        timeDifference = Math.ceil(dateDifference / (1000 *60* 60* 24));
        spanElement.textContent = timeDifference;
        errorMessageContainer.style.display = 'none';
        resultMessage.style.display = 'block';
        
}
}
btnResult.addEventListener('click', calculatedaysUntilBirthday);